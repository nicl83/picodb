HOW TO USE THIS GARBAGE

Libraries needed for the Python script:
qrcode
requests
json

1) make sure there's a valid Github token in config.json
2) check sources.json, make sure the ones you want are there (you can use manage_sources as a frontend)
3) run main to update picoDBinfo
4) run generate_html to generate picodb.html
5) go look at picodb.html